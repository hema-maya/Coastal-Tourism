import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import BeachProfiles from './components/BeachProfiles';
import MarinaBeach from './components/MarinaBeach';
import KovalamBeach from './components/KovalamBeach';
import ElliotBeach from './components/ElliotBeach';
import KanyakumariBeach from './components/KanyakumariBeach';
import RameswaramBeach from './components/RameswaramBeach';
import './App.css';

function AppContent() {
  const location = useLocation();

  return (
    <div className="App">
      {location.pathname === '/' && (
        <>
          <h1 className="main-heading">Beach Profiles</h1>
          <BeachProfiles />
        </>
      )}

      <Routes>
        <Route path="/marina" element={<MarinaBeach />} />
        <Route path="/kovalam" element={<KovalamBeach />} />
        <Route path="/elliot" element={<ElliotBeach />} />
        <Route path="/kanyakumari" element={<KanyakumariBeach />} />
        <Route path="/rameswaram" element={<RameswaramBeach />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
