import React from 'react';

function RameswaramBeach() {
  return <h1>Welcome to Rameswaram Beach</h1>;
}

export default RameswaramBeach;
