import React from 'react';

function ElliotBeach() {
  return <h1>Welcome to Elliot Beach</h1>;
}

export default ElliotBeach;
