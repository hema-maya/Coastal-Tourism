import React from 'react';

function KanyakumariBeach() {
  return <h1>Welcome to Kanyakumari Beach</h1>;
}

export default KanyakumariBeach;
