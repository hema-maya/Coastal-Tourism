import React from 'react';

function KovalamBeach() {
  return <h1>Welcome to Kovalam Beach</h1>;
}

export default KovalamBeach;
